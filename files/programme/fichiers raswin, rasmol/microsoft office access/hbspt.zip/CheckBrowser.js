/* 	This function tests the client browser for four important pieces of information.
	
	1. The browser type (Netscape)
	2. The browser app version (4.0 or higher for Win95, 3.0x for other platforms))
	3. The platform
	3. Whether or not the Chime plug-in is installed and configured to serve the following mime types:
		chemical/x-pdb 				.pdb
		chemical/x-mdl-molfile 		.mol
		
	If any of these conditions are not met, a JavaScript alert box appears advising the user to
	download the needed software. Last updated 9.4.97  */
	
function CheckBrowser()
{
	if (navigator.appVersion.indexOf ("2.0") != -1)
	{
		alert ("A newer version of Netscape Navigator is required for this C4 module.\n\nPlease download version 4.0x (for Windows 95), or version 3.0x (for other platforms).\n\nSee the C4 main page for download information.");
		return;
	}
	if (navigator.appName.indexOf ("Internet Explorer") != -1)
	{
		alert ("\Netscape Navigator is required for this C4 module. Microsoft Internet Explorer is not currently compatible with the Chime plug-in. Please download and install Netscape Navigator version 4.0x for Windows 95, or version 3.0x for other platforms.");
		return;
	}
	var myPluginMol = navigator.mimeTypes ["chemical/x-mdl-molfile"];
	var myPluginPdb = navigator.mimeTypes ["chemical/x-pdb"];
	var myBrowserNav = navigator.appName.indexOf ("Netscape");
	var myBrowserVer3 = navigator.appVersion.indexOf ("3.0");
	var myBrowserVer4 = navigator.appVersion.indexOf ("4.0");
	var myWin95 = navigator.appVersion.indexOf ("Win95");
	var num = 0; outputstring = "";
	var chime_flag = 0, browser_flag = 0, version_flag = 0, links_flag = 0;
	
	var warning = "\nThis C4 module requires the Chime plug-in and Netscape Navigator version 4.0x (for Windows 95) or version 3.0x (for all other platforms).";
	var chime_msg = "\n\nEither you you not have the Chime plug-in, or it is not properly configured. Please download and install Chime, and configure your browser.";
	var browser_msg = "\nYou are not using Netscape Navigator. Microsoft Internet Explorer is not currently compatible with Chime. Please download and install the recommended version of Netscape Navigator.";
	var version_msg = "\nYou are not using Netscape Navigator 4.0x (for Windows 95) or 3.0x (for other platforms). Please download and install the correct version of Netscape.";
	var links_msg = "\n\nOn the C4 main page you will find links to download and configure Navigator and Chime.";
	for (var i = 0; i < navigator.plugins.length; i++)
	{
		if (navigator.plugins[i].name.substring(0,9) == "Chemscape")
		{
			num = i;
			if ((myPluginMol) && (myPluginPdb))
				chime_flag = 1;
		}
	}
	if (myBrowserNav == -1) 
	{
		browser_flag = 0;
		links_flag = 1;
		outputstring += browser_msg;
	}
	
	if ((myBrowserVer3 != -1) || ((myBrowserVer4 != -1) && (myWin95 != -1)))
	{
		browser_flag = 1;
		version_flag = 1;
	}
	else
		version_flag = 0;
		
/*	if ((myBrowserVer4 != -1) && (myWin95 != -1))
	{		browser_flag = 1;
		version_flag = 1;
	}*/
			
	if (chime_flag == 0)
	{
		links_flag = 1;
		outputstring += chime_msg;
	}
	
	if (browser_flag == 0)
		outputstring += browser_msg;
	if (version_flag == 0)
		outputstring += version_msg;	
			
//alert (outputstring);
	if (links_flag == 1)
/*	if ((myBrowserNav == -1) || ((myBrowserVer3 == -1) && (myWin95 == -1)) || ((myBrowserVer4 == -1) && (myWin95 != -1)) || (chime_flag != 1))*/
	{
		alert (warning + outputstring + ((links_flag == 1) ? links_msg : "" + "\nYou are using: " + navigator.appName + " " + navigator.appVersion));
	}
}
