var shade_warned = 0;

function MessageAlert(buttonname, message)
{
	if (message.indexOf("atoms selected!") != -1)
		return;
	else if(message.indexOf("atom selected!") != -1)
		return;
	else if (!(message.length))
		return;
	else if(message.indexOf("script <exiting>") != -1)
		return;
	else if(message.indexOf("Rotating about") != -1)
		return;
	else if(message.indexOf("Unable to allocate shade!") != -1)
		return;
// This occurs when group coloring is applied to Hb, so we'll spare the
// client.
//	{
		// give this warning just once
//		if (shade_warned)
//			return;
//		else
//			shade_warned = 1;
//	}
	alert(message);
}
