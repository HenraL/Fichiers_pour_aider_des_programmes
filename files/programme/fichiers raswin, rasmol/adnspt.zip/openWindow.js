// Function to open windows for tables and such.
// Accepts 4 arguments: source path, window name, height, and width.
function openWindow(source,name,height,width)
{	table_window = window.open (source, name, 
		"toolbar=0,scrollbar=1,status=0,height=" + height + ",width=" + width);
	if (table_window != null) 
	{
		table_window.creator = self;
		table_window.focus();
		// alert (table_window.document.title);
	}
	return;
}
